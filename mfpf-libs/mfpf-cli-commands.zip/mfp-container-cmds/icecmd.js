/*Licensed Materials - Property of IBM
      5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
      US Government Users Restricted Rights - Use, duplication or
      disclosure restricted by GSA ADP Schedule Contract with IBM Corp.*/

/*jslint node:true */
/*jshint node:true */

'use strict';
var moduleName = 'icecmd'; // - name for clarification during logging

//private modules
var strings = require('strings');
var CLISettings = require('clisettings');

var path = require('path');
var Q = require('q');
var spawn = require('child_process').spawn;
var prompt = require('prompt');
prompt.message = "";
prompt.delimiter = "";

var clisettings = new CLISettings();

var commands = ["login", "configdb", "version", "upgradedb","delete", "logout"];

var target = "https://api.ng.bluemix.net";
var user;
var password;

function IceCMD() {
  this.exec = function(args) {
	  if(args.length ==0 || commands.indexOf(args[0]) < 0){
		  console.log("Invalid command");
		  console.log("See 'mfp help container'");
		  return;
	  }
	  
	  if(args[0] != "login"){
		  executeJavaCommand(args);
		  return;
	  }
	  
    var ind = args.indexOf('-a');
    ind = ind >= 0 ? ind : args.indexOf('--api');
    if (ind >= 0 && ind < (args.length - 1)) {
      target = args[ind + 1];
      target = target.replace("http://", "");
      target = target.replace("https://", "");
      target = target.replace("/", "");
      target = "https://" + target;
    }
    
    ind = args.indexOf('-u');
    ind = ind >= 0 ? ind : args.indexOf('--user');
    if(ind >= 0 && ind < (args.length - 1)){
      user = args[ind + 1];
    }
    ind = args.indexOf('-p');
    ind = ind >= 0 ? ind : args.indexOf('--password');
    if(ind >= 0 && ind < (args.length - 1)){
      password = args[ind + 1];
    }
    
    console.log("API endpoint: " + target);
    if(user && password){
      executeJavaCommand(args);
    }
    else{
      
      var properties = [];
      if(!user){
        properties.push({ name: 'username',  description: 'Email>' });
      }
      if(!password){
        properties.push({ name: 'password', hidden: true, description: 'Password>' });
      }
      prompt.start();
      prompt.get(properties, function (err, result) {
        if (err) { 
          console.log(err); 
          return 1; 
        }
        if(!user){
          user = result.username;
          args.push('-u');
          args.push(user);
        }
        if(!password){
          password = result.password;
          args.push('-p');
          args.push(password);
        }
        executeJavaCommand(args);
      });
    }
  }
}

//take a defer for worklight module.  it will:
//- resolve upon successful execution of its container command.
//- reject if the container command has failed for any reason
function executeJavaCommand(args){
  var d = Q.defer(),
          isStdErr = false, response = {stdout: '', stderr: '', code: 1},
          errorResponse, argsStr = '', iceProcess = null,
          validArgs = false, message, ind;
  var jarFile = path.resolve(path.join(__dirname, 'lib'));
  
  var cmd = ['-jar', (jarFile + '/mfp-docker-client.jar')];

  for(var i =0; i<args.length; i++){
    cmd.push(args[i]);
  }
  
  if(args[0] == "configdb"){
    var warFile = path.resolve(path.join(__dirname, 'lib/mfp-docker-app.war'));
    cmd.push("-w");
    cmd.push(warFile);
  }
  if(args[0] == "upgradedb"){
    var upgradeJarFile = path.resolve(path.join(__dirname, '../generator-worklight-server/lib/worklight-ant-deployer.jar'));
    cmd.push("-j");
    cmd.push(upgradeJarFile);
  }
  
  var iceProcess = spawn('java', cmd, {maxBuffer: 80000 * 1024, stdio: [0,'pipe','pipe' ]});
  // specify child process stdout data event handler
  iceProcess.stdout.on('data', function (out) {
    process.stdout.write(out);
    response.stdout += out;
  });

  // specify child process stderr data event handler.
  iceProcess.stderr.on('data', function (err) {
    process.stderr.write(err);
    response.stderr += err;
    isStdErr = true;
  });

  // specify child process close event handler. This event is emitted when
  // the stdio streams of iceProcess have all terminated.
  iceProcess.on('close', function (returnCode) {
    if (!isStdErr) {
      response.code = returnCode;
      //log.silly(moduleName, 'child processes completed with the following stdout: %j', response.stdout);
      d.resolve(response);
    } else {
      errorResponse = new Error(response.stderr);
      errorResponse.code = returnCode;
      var err = JSON.stringify(errorResponse, ['stack', 'message', 'code'], 2),
        json = eval("(" + err + ")");
        d.reject(json);
    }
  });
}

function icecmd(args) {
    var runInstance = new IceCMD();
    runInstance.exec(args);
}

module.exports = icecmd;
