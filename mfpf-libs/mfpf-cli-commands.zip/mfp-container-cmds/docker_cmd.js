/*Licensed Materials - Property of IBM
                5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
                US Government Users Restricted Rights - Use, duplication or
                disclosure restricted by GSA ADP Schedule Contract with IBM Corp.*/
'use strict';

var Q = require('q');
var path = require('path');
var fs = require('fs');
var path = require('path');
var exec = require('child_process').exec;
var icecmd = require('./icecmd');

// MFP commands must return a promise
module.exports.run = function(argv) {
	var deferred = Q.defer();
	icecmd(argv);
	//console.log('Implement the docker command here.' + argv.length);

	// TODO yes, it is silly to resolve this before returning it, but I wanted
	// to stub it out for you anyway ;)
	//deferred.resolve();

	return deferred.promise;
};

// MFP commands must return a promise
module.exports.help = function(argv) {
	var deferred = Q.defer();

	var helpFile = path.resolve(path.join(__dirname, 'help.txt'));
	console.log(helpFile);
	fs.readFile(helpFile, {
		encoding: 'utf8'
	}, function (err, data) {
		if (err) {
		  deferred.resolve(err);
		} else {
		  console.log(data);
		  deferred.resolve();
		}
	});

	return deferred.promise;
};
